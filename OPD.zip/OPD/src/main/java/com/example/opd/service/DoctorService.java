package com.example.opd.service;

import com.example.opd.entity.Doctor;
import com.example.opd.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    // Create a new doctor
    public Doctor createDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    // Get all doctors
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    // Get doctor by ID
    public Doctor getDoctorById(Long id) {
        return doctorRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Doctor not found with ID: " + id));
    }

    // Update doctor
    public Doctor updateDoctor(Long id, Doctor doctorDetails) {

        Doctor doctor = getDoctorById(id);

        doctor.setName(doctorDetails.getName());
        doctor.setSpecialization(
                doctorDetails.getSpecialization()
        );
        doctor.setAverageConsultationTime(
                doctorDetails.getAverageConsultationTime()
        );

        return doctorRepository.save(doctor);
    }

    // Delete doctor
    public void deleteDoctor(Long id) {

        Doctor doctor = getDoctorById(id);

        doctorRepository.delete(doctor);
    }
}