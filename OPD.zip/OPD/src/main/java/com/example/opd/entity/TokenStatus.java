package com.example.opd.entity;

public enum TokenStatus {
    WAITING,
    SERVING,
    SERVED,
    CANCELLED
}