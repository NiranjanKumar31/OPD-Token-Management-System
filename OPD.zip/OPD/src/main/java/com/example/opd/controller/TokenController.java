package com.example.opd.controller;

import com.example.opd.entity.Token;
import com.example.opd.service.TokenService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tokens")
public class TokenController {

    private final TokenService tokenService;

    public TokenController(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    // Generate token
    @PostMapping
    public ResponseEntity<Token> generateToken(
            @RequestParam Long doctorId,
            @RequestParam Long patientId,
            @RequestParam(defaultValue = "false") boolean priority) {

        return new ResponseEntity<>(
                tokenService.generateToken(
                        doctorId,
                        patientId,
                        priority
                ),
                HttpStatus.CREATED
        );
    }

    // Get token by ID
    @GetMapping("/{id}")
    public ResponseEntity<Token> getTokenById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                tokenService.getTokenById(id)
        );
    }

    // Get today's tokens for doctor
    @GetMapping("/doctor/{doctorId}/today")
    public ResponseEntity<List<Token>> getTodayTokens(
            @PathVariable Long doctorId) {

        return ResponseEntity.ok(
                tokenService.getTodayTokens(doctorId)
        );
    }

    // Serve next token
    @PostMapping("/doctor/{doctorId}/next")
    public ResponseEntity<Token> serveNextToken(
            @PathVariable Long doctorId) {

        return ResponseEntity.ok(
                tokenService.serveNextToken(doctorId)
        );
    }

    // Mark token as served
    @PostMapping("/{id}/serve")
    public ResponseEntity<Token> markAsServed(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                tokenService.markAsServed(id)
        );
    }

    // Cancel token
    @PostMapping("/{id}/cancel")
    public ResponseEntity<Token> cancelToken(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                tokenService.cancelToken(id)
        );
    }

    // Get token history
    @GetMapping("/doctor/{doctorId}/history")
    public ResponseEntity<List<Token>> getTokenHistory(
            @PathVariable Long doctorId) {

        return ResponseEntity.ok(
                tokenService.getTokenHistory(doctorId)
        );
    }
}