package com.example.opd.repository;

import com.example.opd.entity.Token;
import com.example.opd.entity.TokenStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TokenRepository extends JpaRepository<Token, Long> {

    List<Token> findByDoctorIdAndTokenDateOrderByTokenNumberAsc(
            Long doctorId,
            LocalDate tokenDate
    );

    Optional<Token> findTopByDoctorIdAndTokenDateOrderByTokenNumberDesc(
            Long doctorId,
            LocalDate tokenDate
    );

    List<Token> findByDoctorIdAndTokenDateAndStatusOrderByTokenNumberAsc(
            Long doctorId,
            LocalDate tokenDate,
            TokenStatus status
    );

    Optional<Token> findFirstByDoctorIdAndTokenDateAndPriorityTrueAndStatusOrderByIdAsc(
            Long doctorId,
            LocalDate tokenDate,
            TokenStatus status
    );
}