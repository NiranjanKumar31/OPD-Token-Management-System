package com.example.opd.service;

import com.example.opd.entity.Patient;
import com.example.opd.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    // Create a new patient
    public Patient createPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    // Get all patients
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    // Get patient by ID
    public Patient getPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Patient not found with ID: " + id));
    }

    // Update patient
    public Patient updatePatient(Long id, Patient patientDetails) {

        Patient patient = getPatientById(id);

        patient.setName(patientDetails.getName());
        patient.setPhone(patientDetails.getPhone());
        patient.setAge(patientDetails.getAge());

        return patientRepository.save(patient);
    }

    // Delete patient
    public void deletePatient(Long id) {

        Patient patient = getPatientById(id);

        patientRepository.delete(patient);
    }
}