package com.example.opd.service;

import com.example.opd.entity.Doctor;
import com.example.opd.entity.Patient;
import com.example.opd.entity.Token;
import com.example.opd.entity.TokenStatus;
import com.example.opd.repository.DoctorRepository;
import com.example.opd.repository.PatientRepository;
import com.example.opd.repository.TokenRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class TokenService {

    private final TokenRepository tokenRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;

    public TokenService(TokenRepository tokenRepository,
                        DoctorRepository doctorRepository,
                        PatientRepository patientRepository) {

        this.tokenRepository = tokenRepository;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
    }

    // Generate a new token
    @Transactional
    public Token generateToken(Long doctorId,
                               Long patientId,
                               boolean priority) {

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Doctor not found with ID: " + doctorId));

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Patient not found with ID: " + patientId));

        LocalDate today = LocalDate.now();

        // Only one active priority token is allowed
        if (priority) {

            boolean priorityAlreadyActive =
                    tokenRepository
                            .findFirstByDoctorIdAndTokenDateAndPriorityTrueAndStatusOrderByIdAsc(
                                    doctorId,
                                    today,
                                    TokenStatus.WAITING
                            )
                            .isPresent();

            if (priorityAlreadyActive) {
                throw new RuntimeException(
                        "A priority token is already active for this doctor."
                );
            }
        }

        // Find the last token number for today
        int nextTokenNumber = tokenRepository
                .findTopByDoctorIdAndTokenDateOrderByTokenNumberDesc(
                        doctorId,
                        today
                )
                .map(token -> token.getTokenNumber() + 1)
                .orElse(1);

        Token token = new Token();

        token.setTokenNumber(nextTokenNumber);
        token.setTokenDate(today);
        token.setStatus(TokenStatus.WAITING);
        token.setPriority(priority);
        token.setEstimatedWaitTime(0);
        token.setDoctor(doctor);
        token.setPatient(patient);

        calculateWaitingTime(token);

        return tokenRepository.save(token);
    }

    // Get all today's tokens for a doctor
    public List<Token> getTodayTokens(Long doctorId) {

        return tokenRepository
                .findByDoctorIdAndTokenDateOrderByTokenNumberAsc(
                        doctorId,
                        LocalDate.now()
                );
    }

    // Get token by ID
    public Token getTokenById(Long id) {

        return tokenRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Token not found with ID: " + id));
    }

    // Serve the next patient
    @Transactional
    public Token serveNextToken(Long doctorId) {

        LocalDate today = LocalDate.now();

        // First look for an active priority token
        List<Token> priorityTokens =
                tokenRepository
                        .findByDoctorIdAndTokenDateAndStatusOrderByTokenNumberAsc(
                                doctorId,
                                today,
                                TokenStatus.WAITING
                        );

        Token nextToken = priorityTokens.stream()
                .filter(Token::isPriority)
                .findFirst()
                .orElseGet(() ->
                        priorityTokens.stream()
                                .filter(token -> !token.isPriority())
                                .findFirst()
                                .orElseThrow(() ->
                                        new RuntimeException(
                                                "No waiting tokens available."
                                        )
                                )
                );

        nextToken.setStatus(TokenStatus.SERVING);

        return tokenRepository.save(nextToken);
    }

    // Mark a token as served
    @Transactional
    public Token markAsServed(Long tokenId) {

        Token token = getTokenById(tokenId);

        if (token.getStatus() != TokenStatus.SERVING) {
            throw new RuntimeException(
                    "Only a serving token can be marked as served."
            );
        }

        token.setStatus(TokenStatus.SERVED);

        return tokenRepository.save(token);
    }

    // Cancel a token
    @Transactional
    public Token cancelToken(Long tokenId) {

        Token token = getTokenById(tokenId);

        if (token.getStatus() == TokenStatus.SERVED) {
            throw new RuntimeException(
                    "A served token cannot be cancelled."
            );
        }

        token.setStatus(TokenStatus.CANCELLED);

        return tokenRepository.save(token);
    }

    // Calculate estimated waiting time
    private void calculateWaitingTime(Token newToken) {

        Doctor doctor = newToken.getDoctor();

        List<Token> waitingTokens =
                tokenRepository
                        .findByDoctorIdAndTokenDateAndStatusOrderByTokenNumberAsc(
                                doctor.getId(),
                                LocalDate.now(),
                                TokenStatus.WAITING
                        );

        int waitingCount = waitingTokens.size();

        int averageTime =
                doctor.getAverageConsultationTime() != null
                        ? doctor.getAverageConsultationTime()
                        : 10;

        newToken.setEstimatedWaitTime(
                waitingCount * averageTime
        );
    }

    // Get token history for a doctor
    public List<Token> getTokenHistory(Long doctorId) {

        return tokenRepository
                .findByDoctorIdAndTokenDateOrderByTokenNumberAsc(
                        doctorId,
                        LocalDate.now()
                );
    }
}